# The ATTRIBUTES block is required.
BEGIN ATTRIBUTES
  NAME rch_2
  METHODS linear 
END ATTRIBUTES

BEGIN TIMESERIES
#time   zone-2
0.0     0.0016
1.0     0.0018
11.0    0.0019
21.0    0.0016
31.0    0.0018
END TIMESERIES
