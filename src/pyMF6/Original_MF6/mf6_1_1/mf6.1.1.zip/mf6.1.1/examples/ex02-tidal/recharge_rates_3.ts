# The ATTRIBUTES block is required.
BEGIN ATTRIBUTES
  NAME rch_3
  METHODS  linear
END ATTRIBUTES

BEGIN TIMESERIES
#time   zone-3
0.0     0.0017
1.0     0.0020
11.0    0.0017
21.0    0.0018
31.0    0.0020
END TIMESERIES
