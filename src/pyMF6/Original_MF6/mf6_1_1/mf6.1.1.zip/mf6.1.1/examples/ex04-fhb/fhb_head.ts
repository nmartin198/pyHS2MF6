BEGIN ATTRIBUTES
  NAME head
  METHODS linearend
END ATTRIBUTES

BEGIN TIMESERIES
# time  head
   0.0    0.
  307.    1.
  791.    5.
 1000.    2.
END TIMESERIES
 