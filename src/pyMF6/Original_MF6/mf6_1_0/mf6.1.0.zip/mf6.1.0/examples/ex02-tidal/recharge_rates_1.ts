# The ATTRIBUTES block is required.
BEGIN ATTRIBUTES
  NAME rch_1 
  METHODS stepwise
END ATTRIBUTES

BEGIN TIMESERIES
#time   zone-1
0.0     0.0015
1.0     0.0010
11.0    0.0015
21.0    0.0025
31.0    0.0015
END TIMESERIES
